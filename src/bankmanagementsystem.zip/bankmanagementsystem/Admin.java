/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanagementsystem;

/**
 *
 * @author madih
 */
public class Admin {
   final String username;
   final String adminId;
   final String password;

    public Admin(String username, String adminId, String password) {
        this.username = username;
        this.adminId = adminId;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getAdminId() {
        return adminId;
    }

    public String getPassword() {
        return password;
    }
   
}
