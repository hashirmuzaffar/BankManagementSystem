/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author madih
 */
public class User implements Comparable<User>{

    String firstName;
    String lastName;
    String gender;
    String contactNumber;
    String dateOfBirth;
    String address;
    String branchCode;
    String accountNumber;
// 00101001
    String dateCreated;
    String pincode;
    String emailAddress;
    String userId;
    String password;
    double accountBalance;
    ArrayList<Transaction> transactionHistory;

    public User(String accountNumber, String firstName, String lastName, double accountBalance) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
    }
    
    public User(String firstName, String lastName, String accountNumber, String gender, String contactNumber, String dateOfBirth, String address, String branchCode, String dateCreated, String pincode, String emailAddress, String userId, String password, double accountBalance, ArrayList<Transaction> transactionHistory) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.branchCode = branchCode;
        this.accountNumber = accountNumber;
        this.dateCreated = dateCreated;
        this.pincode = pincode;
        this.emailAddress = emailAddress;
        this.userId = userId;
        this.password = password;
        this.transactionHistory = new ArrayList<>();
    }
    
//    public void viewTransactionReport()
//    public void viewAccountBalance()
//    public void viewLoanApplicationStatus()
//    public void applyForLoan()

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
    
    public void updateBalanceAfterTransaction(String transactionType, double amount){
        this.accountBalance = getAccountBalance();
        if(transactionType.equalsIgnoreCase("Withdraw")){
            accountBalance -= amount;
        }
        else if(transactionType.equalsIgnoreCase("Deposit")){
            accountBalance += amount;
        }
    }
    
    public void addTransaction(Transaction transaction){
        transactionHistory.add(transaction);
    }
    
    public int transactionLength(){
        return transactionHistory.size();
    }
    
    public ArrayList<Transaction> getTransaction(){
        return transactionHistory;
    }

    @Override
    public String toString() {
        return "User{" + "firstName=" + firstName + ", lastName=" + lastName + ", accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + '}';
    }

    @Override
    public int compareTo(User user) {
       return this.firstName.compareTo(user.firstName);
    }
    
}

