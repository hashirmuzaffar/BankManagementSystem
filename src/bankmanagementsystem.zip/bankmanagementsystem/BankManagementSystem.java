/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanagementsystem;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author madih
 */
public class BankManagementSystem {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StorageManager.initialize();
        StorageManager storageManager = StorageManager.getInstance();
        storageManager.printHashTable();
        System.out.println("Tester" + storageManager.usersHashTable.get("0000"));
        try {
            storageManager.addUser(new User("108900234", "Nagina", "Abid", 12));
        } catch (Exception ex) {
            Logger.getLogger(BankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
//HashTable<String, String> a = new HashTable<String, String>(2);
//a.insertNode("20", "Lilly");
////a.insertNode("32", "Hannah");
////a.insertNode("21", "Polly");
//System.out.println(a.get("20"));
    }
}
